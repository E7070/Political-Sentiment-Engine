import re
import pandas as pd
import os
from collections import Counter

PROPAGANDA_KEYWORDS = [
    'russia', 'russian', 'putin', 'kremlin', 'ukraine', 'ukrainians',
    'nato', 'zelensky', 'donbass', 'donetsk', 'kherson', 'mariupol',
    'invasion', 'war', 'attack', 'troops', 'military', 'soldiers',
    'genocide', 'propaganda', 'fake', 'lies', 'truth',
    'fake news', 'msm', 'mainstream media', 'deep state', 'globalist',
    'radical', 'extremist', 'terrorist', 'regime', 'puppet',
    'murder', 'massacre', 'slaughter', 'civilians', 'children',
    'freedom', 'liberty', 'corrupt', 'traitor', 'spy',
]

HASHTAG_PROPAGANDA = [
    'russianattack', 'russianarmedforces', 'russiainvaded',
    'deadrussiansoldiers', 'trumprussia', 'putinwar',
    'ukrainewar', 'stoprussia', 'standwithukraine',
]

def clean_text(text: str) -> str:
    if not isinstance(text, str):
        return ""
    text = re.sub(r'http\S+|www\S+', '', text)
    text = re.sub(r'@\w+', '', text)
    text = re.sub(r'^RT\s+', '', text)
    text = re.sub(r'&amp;|&lt;|&gt;|&quot;', ' ', text)
    text = re.sub(r'[^\w\s#]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text.lower()

def extract_hashtags(text: str) -> list:
    return re.findall(r'#(\w+)', text.lower())

def extract_features(text: str) -> dict:
    raw = text
    cleaned = clean_text(text)
    hashtags = extract_hashtags(raw)
    prop_count = sum(1 for kw in PROPAGANDA_KEYWORDS if kw in cleaned)
    prop_hashtag_count = sum(1 for ht in hashtags if ht in HASHTAG_PROPAGANDA)
    is_retweet = raw.strip().startswith('RT ')
    caps_words = len(re.findall(r'\b[A-Z]{3,}\b', raw))
    exclamations = raw.count('!')
    questions = raw.count('?')
    word_count = len(cleaned.split())
    hashtag_count = len(hashtags)
    return {
        'cleaned_text': cleaned,
        'hashtags': hashtags,
        'hashtag_count': hashtag_count,
        'prop_keyword_count': prop_count,
        'prop_hashtag_count': prop_hashtag_count,
        'is_retweet': int(is_retweet),
        'caps_word_count': caps_words,
        'exclamation_count': exclamations,
        'question_count': questions,
        'word_count': word_count,
    }

def load_dataset(csv_path: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path, encoding='utf-8')
    df.columns = [c.strip().lower() for c in df.columns]
    df['text'] = df['text'].fillna('')
    df['user'] = df['user'].fillna('unknown')
    df['sentiment'] = df['sentiment'].fillna('neutral')
    features = df['text'].apply(extract_features)
    features_df = pd.DataFrame(features.tolist())
    df = pd.concat([df.reset_index(drop=True), features_df.reset_index(drop=True)], axis=1)
    sentiment_map = {'positive': 1, 'neutral': 0, 'negative': -1}
    df['sentiment_score'] = df['sentiment'].map(sentiment_map).fillna(0)
    return df

def get_top_hashtags(df: pd.DataFrame, n: int = 10) -> dict:
    all_tags = []
    for tags in df['hashtags']:
        if isinstance(tags, list):
            all_tags.extend(tags)
    return dict(Counter(all_tags).most_common(n))

def get_user_stats(df: pd.DataFrame) -> pd.DataFrame:
    stats = df.groupby('user').agg(
        tweet_count=('text', 'count'),
        avg_prop_score=('prop_keyword_count', 'mean'),
        total_hashtags=('hashtag_count', 'sum'),
        retweet_count=('is_retweet', 'sum'),
        sentiment_avg=('sentiment_score', 'mean'),
    ).reset_index()
    return stats.sort_values('tweet_count', ascending=False)