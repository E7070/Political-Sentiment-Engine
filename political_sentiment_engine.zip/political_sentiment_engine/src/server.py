import sys
import os
import pandas as pd

sys.path.insert(0, os.path.dirname(__file__))

from preprocess import load_dataset, get_top_hashtags, get_user_stats
from sentiment_analysis import analyze_all, get_sentiment_summary
from propaganda_detection import (
    analyze_propaganda, train_ml_classifier, predict_single
)
from graph_module import (
    build_user_network, detect_bot_suspects,
    get_network_stats, get_propaganda_clusters
)

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget,
    QVBoxLayout, QHBoxLayout, QPushButton,
    QLabel, QTableWidget, QTableWidgetItem,
    QTextEdit, QFrame, QHeaderView,
    QTabWidget, QLineEdit, QProgressBar,
    QMessageBox, QSplitter
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt6.QtGui import QFont, QColor


class AnalysisWorker(QThread):
    progress = pyqtSignal(int)
    status   = pyqtSignal(str)
    finished = pyqtSignal(dict)
    error    = pyqtSignal(str)

    def __init__(self, csv_path):
        super().__init__()
        self.csv_path = csv_path

    def run(self):
        try:
            self.status.emit("📂 Loading dataset...")
            self.progress.emit(10)
            df = load_dataset(self.csv_path)

            self.status.emit("🔍 Running NLP analysis...")
            self.progress.emit(30)
            df = analyze_all(df)

            self.status.emit("🦠 Detecting propaganda...")
            self.progress.emit(50)
            df = analyze_propaganda(df)

            self.status.emit("🤖 Training ML model...")
            self.progress.emit(65)
            clf, vectorizer, accuracy = train_ml_classifier(df)

            self.status.emit("🕸️ Building network graph...")
            self.progress.emit(80)
            G = build_user_network(df)
            bot_suspects = detect_bot_suspects(G, df)
            net_stats = get_network_stats(G)
            clusters = get_propaganda_clusters(G, df)

            self.status.emit("📊 Generating summary...")
            self.progress.emit(95)
            sentiment_summary = get_sentiment_summary(df)
            top_hashtags = get_top_hashtags(df)
            user_stats = get_user_stats(df)

            self.progress.emit(100)
            self.status.emit("✅ Analysis complete!")

            self.finished.emit({
                'df': df,
                'clf': clf,
                'vectorizer': vectorizer,
                'accuracy': accuracy,
                'G': G,
                'bot_suspects': bot_suspects,
                'net_stats': net_stats,
                'clusters': clusters,
                'sentiment_summary': sentiment_summary,
                'top_hashtags': top_hashtags,
                'user_stats': user_stats,
            })
        except Exception as e:
            self.error.emit(str(e))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(
            "🛡️ Political Sentiment & Propaganda Detection Engine"
        )
        self.setMinimumSize(1100, 720)
        self.data = {}
        self.setup_ui()
        self.apply_styles()

    def setup_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setSpacing(8)
        layout.setContentsMargins(12, 12, 12, 12)

        header = QFrame()
        header.setObjectName("header")
        h_layout = QHBoxLayout(header)

        title_col = QVBoxLayout()
        title = QLabel("🛡️ Political Sentiment & Propaganda Detection Engine")
        title.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        title.setObjectName("title")
        subtitle = QLabel(
            "NLP + Graph ML powered real-time propaganda analysis"
        )
        subtitle.setObjectName("subtitle")
        title_col.addWidget(title)
        title_col.addWidget(subtitle)
        h_layout.addLayout(title_col)
        h_layout.addStretch()

        self.load_btn = QPushButton("📂 Load Dataset")
        self.load_btn.setObjectName("loadBtn")
        self.load_btn.setFixedHeight(38)
        self.load_btn.clicked.connect(self.load_data)
        h_layout.addWidget(self.load_btn)
        layout.addWidget(header)

        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(16)
        self.progress_bar.setObjectName("progress")
        self.progress_bar.setValue(0)
        layout.addWidget(self.progress_bar)

        self.status_label = QLabel("⏳ Load a dataset to begin analysis...")
        self.status_label.setObjectName("statusLabel")
        layout.addWidget(self.status_label)

        cards_layout = QHBoxLayout()
        self.card_total    = self.make_card("📝 Total Tweets", "0", "#a78bfa")
        self.card_positive = self.make_card("✅ Positive", "0", "#34d399")
        self.card_negative = self.make_card("❌ Negative", "0", "#f87171")
        self.card_neutral  = self.make_card("⚪ Neutral", "0", "#9ca3af")
        self.card_prop     = self.make_card("🦠 High Propaganda", "0", "#f59e0b")
        self.card_bots     = self.make_card("🤖 Bot Suspects", "0", "#ef4444")
        self.card_accuracy = self.make_card("🎯 ML Accuracy", "0%", "#60a5fa")
        for card in [self.card_total, self.card_positive,
                     self.card_negative, self.card_neutral,
                     self.card_prop, self.card_bots,
                     self.card_accuracy]:
            cards_layout.addWidget(card[0])
        layout.addLayout(cards_layout)

        self.tabs = QTabWidget()
        self.tabs.setObjectName("tabs")

        tab1 = QWidget()
        t1_layout = QVBoxLayout(tab1)

        search_row = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText(
            "🔍 Search tweets or enter new text to analyze..."
        )
        self.search_input.setObjectName("searchInput")
        search_row.addWidget(self.search_input)

        analyze_btn = QPushButton("🔍 Analyze Text")
        analyze_btn.setObjectName("analyzeBtn")
        analyze_btn.clicked.connect(self.analyze_single)
        search_row.addWidget(analyze_btn)
        t1_layout.addLayout(search_row)

        self.single_result = QLabel("")
        self.single_result.setObjectName("singleResult")
        self.single_result.setWordWrap(True)
        t1_layout.addWidget(self.single_result)

        self.tweet_table = QTableWidget()
        self.tweet_table.setColumnCount(6)
        self.tweet_table.setHorizontalHeaderLabels([
            "User", "Sentiment", "NLP Score",
            "Propaganda Score", "Level", "Tweet Preview"
        ])
        self.tweet_table.horizontalHeader().setSectionResizeMode(
            5, QHeaderView.ResizeMode.Stretch
        )
        self.tweet_table.setColumnWidth(0, 100)
        self.tweet_table.setColumnWidth(1, 80)
        self.tweet_table.setColumnWidth(2, 80)
        self.tweet_table.setColumnWidth(3, 120)
        self.tweet_table.setColumnWidth(4, 120)
        self.tweet_table.setEditTriggers(
            QTableWidget.EditTrigger.NoEditTriggers
        )
        self.tweet_table.setObjectName("table")
        self.tweet_table.setAlternatingRowColors(True)
        t1_layout.addWidget(self.tweet_table)
        self.tabs.addTab(tab1, "📝 Tweet Analysis")

        tab2 = QWidget()
        t2_layout = QVBoxLayout(tab2)

        self.user_table = QTableWidget()
        self.user_table.setColumnCount(6)
        self.user_table.setHorizontalHeaderLabels([
            "User", "Tweets", "Avg Propaganda Score",
            "Hashtags", "Retweets", "Bot Suspect"
        ])
        self.user_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.user_table.setEditTriggers(
            QTableWidget.EditTrigger.NoEditTriggers
        )
        self.user_table.setObjectName("table")
        self.user_table.setAlternatingRowColors(True)
        t2_layout.addWidget(self.user_table)
        self.tabs.addTab(tab2, "🕸️ User Network")

        tab3 = QWidget()
        t3_layout = QVBoxLayout(tab3)

        self.cluster_table = QTableWidget()
        self.cluster_table.setColumnCount(4)
        self.cluster_table.setHorizontalHeaderLabels([
            "Cluster ID", "Users", "Avg Propaganda Score", "Risk Level"
        ])
        self.cluster_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.cluster_table.setEditTriggers(
            QTableWidget.EditTrigger.NoEditTriggers
        )
        self.cluster_table.setObjectName("table")
        t3_layout.addWidget(self.cluster_table)
        self.tabs.addTab(tab3, "🔴 Propaganda Clusters")

        tab4 = QWidget()
        t4_layout = QVBoxLayout(tab4)

        self.hashtag_table = QTableWidget()
        self.hashtag_table.setColumnCount(2)
        self.hashtag_table.setHorizontalHeaderLabels([
            "Hashtag", "Count"
        ])
        self.hashtag_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.hashtag_table.setEditTriggers(
            QTableWidget.EditTrigger.NoEditTriggers
        )
        self.hashtag_table.setObjectName("table")
        t4_layout.addWidget(self.hashtag_table)
        self.tabs.addTab(tab4, "# Top Hashtags")

        tab5 = QWidget()
        t5_layout = QVBoxLayout(tab5)
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setObjectName("log")
        self.log.setFont(QFont("Courier", 9))
        t5_layout.addWidget(self.log)
        self.tabs.addTab(tab5, "📋 Analysis Log")

        layout.addWidget(self.tabs)

    def make_card(self, title, value, color):
        frame = QFrame()
        frame.setObjectName("card")
        fl = QVBoxLayout(frame)
        fl.setSpacing(2)
        tl = QLabel(title)
        tl.setFont(QFont("Arial", 8))
        tl.setObjectName("cardTitle")
        tl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        vl = QLabel(value)
        vl.setFont(QFont("Arial", 20, QFont.Weight.Bold))
        vl.setStyleSheet(f"color: {color};")
        vl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        fl.addWidget(tl)
        fl.addWidget(vl)
        return frame, vl

    def apply_styles(self):
        self.setStyleSheet("""
            QMainWindow, QWidget {
                background-color: #0d0d1a;
                color: #e2e8f0;
            }
            #header {
                background-color: #1e1e2e;
                border-radius: 10px;
                padding: 10px;
                border: 1px solid #7c3aed;
            }
            #title { color: #a78bfa; }
            #subtitle { color: #6b7280; font-size: 11px; }
            #card {
                background-color: #1e1e2e;
                border-radius: 8px;
                border: 1px solid #374151;
                padding: 8px;
                min-height: 70px;
            }
            #cardTitle { color: #9ca3af; font-size: 9px; }
            QTabWidget::pane {
                border: 1px solid #374151;
                background-color: #1e1e2e;
                border-radius: 8px;
            }
            QTabBar::tab {
                background-color: #2e2e3e;
                color: #9ca3af;
                padding: 7px 16px;
                border-radius: 4px;
                margin-right: 3px;
                font-size: 11px;
            }
            QTabBar::tab:selected {
                background-color: #7c3aed;
                color: white;
            }
            QTabBar::tab:hover { background-color: #374151; }
            QPushButton#loadBtn {
                background-color: #7c3aed;
                color: white;
                border-radius: 8px;
                padding: 6px 16px;
                font-weight: bold;
                font-size: 12px;
            }
            QPushButton#loadBtn:hover { background-color: #6d28d9; }
            QPushButton#analyzeBtn {
                background-color: #059669;
                color: white;
                border-radius: 6px;
                padding: 6px 14px;
                font-weight: bold;
            }
            QPushButton#analyzeBtn:hover { background-color: #047857; }
            QLineEdit#searchInput {
                background-color: #1e1e2e;
                color: #e2e8f0;
                border: 1px solid #374151;
                border-radius: 6px;
                padding: 7px 12px;
                font-size: 11px;
            }
            QLineEdit#searchInput:focus { border-color: #7c3aed; }
            QProgressBar#progress {
                background-color: #2e2e3e;
                border-radius: 8px;
                text-align: center;
                color: white;
                font-size: 9px;
                border: 1px solid #374151;
            }
            QProgressBar#progress::chunk {
                background-color: #7c3aed;
                border-radius: 8px;
            }
            #statusLabel { color: #9ca3af; font-size: 10px; }
            #singleResult {
                color: #e2e8f0;
                background-color: #2e2e3e;
                border-radius: 8px;
                padding: 8px 12px;
                font-size: 11px;
                border: 1px solid #374151;
            }
            QTableWidget#table {
                background-color: #151525;
                alternate-background-color: #1e1e2e;
                color: #e2e8f0;
                gridline-color: #374151;
                border: 1px solid #374151;
                border-radius: 6px;
                font-size: 10px;
            }
            QHeaderView::section {
                background-color: #7c3aed;
                color: white;
                padding: 7px;
                border: none;
                font-weight: bold;
                font-size: 10px;
            }
            QTextEdit#log {
                background-color: #0a0a1a;
                color: #6ee7b7;
                border: 1px solid #374151;
                border-radius: 8px;
                font-family: Courier;
            }
            QScrollBar:vertical {
                background-color: #1e1e2e;
                width: 8px;
                border-radius: 4px;
            }
            QScrollBar::handle:vertical {
                background-color: #7c3aed;
                border-radius: 4px;
            }
        """)

    def add_log(self, msg, level="INFO"):
        import datetime
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        colors = {
            "INFO": "#6ee7b7", "WARNING": "#fbbf24",
            "ERROR": "#f87171", "SUCCESS": "#34d399"
        }
        c = colors.get(level, "#6ee7b7")
        self.log.append(
            f'<span style="color:{c}">'
            f'[{ts}] [{level}] {msg}</span>'
        )

    def load_data(self):
        from PyQt6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getOpenFileName(
            self, "Select CSV Dataset", "",
            "CSV Files (*.csv)"
        )
        if not path:
            return

        self.load_btn.setEnabled(False)
        self.progress_bar.setValue(0)
        self.add_log(f"Loading: {path}", "INFO")

        self.worker = AnalysisWorker(path)
        self.worker.progress.connect(self.progress_bar.setValue)
        self.worker.status.connect(self.status_label.setText)
        self.worker.finished.connect(self.on_analysis_done)
        self.worker.error.connect(self.on_error)
        self.worker.start()

    def on_error(self, msg):
        self.add_log(f"Error: {msg}", "ERROR")
        self.load_btn.setEnabled(True)
        QMessageBox.critical(self, "❌ Error", msg)

    def on_analysis_done(self, results):
        self.data = results
        self.load_btn.setEnabled(True)
        df = results['df']
        ss = results['sentiment_summary']
        bots = results['bot_suspects']

        self.card_total[1].setText(str(len(df)))
        self.card_positive[1].setText(str(ss.get('positive', 0)))
        self.card_negative[1].setText(str(ss.get('negative', 0)))
        self.card_neutral[1].setText(str(ss.get('neutral', 0)))

        high_prop = len(df[df['propaganda_level'] == 'HIGH']) \
            if 'propaganda_level' in df.columns else 0
        self.card_prop[1].setText(str(high_prop))

        bot_count = sum(
            1 for v in bots.values() if v.get('is_suspect')
        )
        self.card_bots[1].setText(str(bot_count))
        self.card_accuracy[1].setText(
            f"{results['accuracy']}%"
        )

        self.populate_tweet_table(df)
        self.populate_user_table(
            results['user_stats'], bots
        )
        self.populate_cluster_table(results['clusters'])
        self.populate_hashtag_table(results['top_hashtags'])

        self.add_log(
            f"✅ Analysis done! {len(df)} tweets, "
            f"{high_prop} high propaganda, "
            f"{bot_count} bot suspects",
            "SUCCESS"
        )

    def populate_tweet_table(self, df):
        self.tweet_table.setRowCount(0)
        for _, row in df.iterrows():
            r = self.tweet_table.rowCount()
            self.tweet_table.insertRow(r)

            user = str(row.get('user', ''))
            sentiment = str(row.get('sentiment', ''))
            nlp_score = str(row.get('nlp_score', ''))
            prop_score = str(row.get('propaganda_score', ''))
            prop_label = str(row.get('propaganda_label', ''))
            preview = str(row.get('text', ''))[:80] + '...'

            for col, val in enumerate([
                user, sentiment, nlp_score,
                prop_score, prop_label, preview
            ]):
                item = QTableWidgetItem(val)
                item.setTextAlignment(
                    Qt.AlignmentFlag.AlignCenter
                )
                self.tweet_table.setItem(r, col, item)

            level = row.get('propaganda_level', 'CLEAN')
            color_map = {
                'HIGH': '#3d0000', 'MEDIUM': '#3d2d00',
                'LOW': '#2d2d00', 'CLEAN': '#0d1f0d'
            }
            bg = QColor(color_map.get(level, '#1e1e2e'))
            for col in range(6):
                item = self.tweet_table.item(r, col)
                if item:
                    item.setBackground(bg)

    def populate_user_table(self, user_stats, bots):
        self.user_table.setRowCount(0)
        for _, row in user_stats.iterrows():
            r = self.user_table.rowCount()
            self.user_table.insertRow(r)

            user = str(row.get('user', ''))
            bot_info = bots.get(user, {})
            is_bot = "🤖 YES" if bot_info.get('is_suspect') else "✅ NO"

            for col, val in enumerate([
                user,
                str(int(row.get('tweet_count', 0))),
                str(round(row.get('avg_prop_score', 0), 1)),
                str(int(row.get('total_hashtags', 0))),
                str(int(row.get('retweet_count', 0))),
                is_bot,
            ]):
                item = QTableWidgetItem(val)
                item.setTextAlignment(
                    Qt.AlignmentFlag.AlignCenter
                )
                self.user_table.setItem(r, col, item)

            if bot_info.get('is_suspect'):
                for col in range(6):
                    item = self.user_table.item(r, col)
                    if item:
                        item.setBackground(QColor('#3d0000'))

    def populate_cluster_table(self, clusters):
        self.cluster_table.setRowCount(0)
        for c in clusters:
            r = self.cluster_table.rowCount()
            self.cluster_table.insertRow(r)
            users_str = ', '.join(c.get('users', []))
            risk = c.get('risk_level', 'LOW')
            risk_label = {
                'HIGH': '🔴 HIGH', 'MEDIUM': '🟡 MEDIUM',
                'LOW': '🟢 LOW'
            }.get(risk, risk)

            for col, val in enumerate([
                str(c.get('cluster_id', '')),
                users_str,
                str(c.get('avg_propaganda_score', 0)),
                risk_label,
            ]):
                item = QTableWidgetItem(val)
                item.setTextAlignment(
                    Qt.AlignmentFlag.AlignCenter
                )
                self.cluster_table.setItem(r, col, item)

            color = {'HIGH': '#3d0000', 'MEDIUM': '#3d2d00',
                     'LOW': '#0d1f0d'}.get(risk, '#1e1e2e')
            for col in range(4):
                item = self.cluster_table.item(r, col)
                if item:
                    item.setBackground(QColor(color))

    def populate_hashtag_table(self, top_hashtags):
        self.hashtag_table.setRowCount(0)
        for tag, count in top_hashtags.items():
            r = self.hashtag_table.rowCount()
            self.hashtag_table.insertRow(r)
            for col, val in enumerate([f'#{tag}', str(count)]):
                item = QTableWidgetItem(val)
                item.setTextAlignment(
                    Qt.AlignmentFlag.AlignCenter
                )
                self.hashtag_table.setItem(r, col, item)

    def analyze_single(self):
        text = self.search_input.text().strip()
        if not text:
            return

        clf = self.data.get('clf')
        vectorizer = self.data.get('vectorizer')
        result = predict_single(text, clf, vectorizer)

        sentiment = result.get('sentiment', 'neutral').upper()
        prop_score = result.get('propaganda_score', 0)
        prop_label = result.get('propaganda_label', '')
        confidence = result.get('confidence', 0)

        self.single_result.setText(
            f"<b>Sentiment:</b> {sentiment}  |  "
            f"<b>Confidence:</b> {confidence}%  |  "
            f"<b>Propaganda Score:</b> {prop_score}/100  |  "
            f"<b>Level:</b> {prop_label}"
        )
        self.add_log(
            f"Analyzed: '{text[:50]}...' → "
            f"{sentiment} | {prop_label}",
            "INFO"
        )


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()