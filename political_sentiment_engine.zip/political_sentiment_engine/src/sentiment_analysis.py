import pandas as pd
import numpy as np
import re
from collections import Counter

POSITIVE_WORDS = [
    'good', 'great', 'excellent', 'amazing', 'wonderful', 'best',
    'love', 'happy', 'peace', 'hope', 'support', 'help', 'strong',
    'victory', 'win', 'success', 'brave', 'hero', 'freedom', 'ready',
    'celebrate', 'proud', 'unity', 'together', 'safe', 'protect',
]

NEGATIVE_WORDS = [
    'bad', 'terrible', 'horrible', 'awful', 'worst', 'hate',
    'kill', 'war', 'attack', 'bomb', 'death', 'dead', 'murder',
    'terror', 'fear', 'panic', 'crisis', 'chaos', 'destroy',
    'invasion', 'corrupt', 'evil', 'threat', 'danger', 'loss',
    'pain', 'suffer', 'victim', 'refugee', 'flee', 'burn',
]

NEUTRAL_WORDS = [
    'said', 'says', 'report', 'according', 'statement',
    'today', 'announced', 'official', 'government', 'minister',
]

def analyze_sentiment_score(text: str) -> dict:
    if not isinstance(text, str):
        return {'score': 0.0, 'label': 'neutral', 'confidence': 0.0}

    text_lower = text.lower()
    words = re.findall(r'\b\w+\b', text_lower)

    pos = sum(1 for w in words if w in POSITIVE_WORDS)
    neg = sum(1 for w in words if w in NEGATIVE_WORDS)
    total = len(words) if len(words) > 0 else 1

    raw_score = (pos - neg) / total
    score = max(-1.0, min(1.0, raw_score * 10))

    confidence = min(1.0, (pos + neg) / max(total * 0.3, 1))

    if score > 0.1:
        label = 'positive'
    elif score < -0.1:
        label = 'negative'
    else:
        label = 'neutral'

    return {
        'score': round(score, 3),
        'label': label,
        'confidence': round(confidence, 3),
        'pos_words': pos,
        'neg_words': neg,
    }

def get_emotion_profile(text: str) -> dict:
    text_lower = text.lower()
    emotions = {
        'anger': ['angry', 'furious', 'rage', 'outrage', 'kill', 'hate', 'attack', 'war', 'bomb'],
        'fear': ['fear', 'scared', 'threat', 'danger', 'terror', 'panic', 'crisis', 'flee'],
        'sadness': ['sad', 'tragedy', 'victim', 'death', 'dead', 'loss', 'pain', 'suffer', 'cry'],
        'disgust': ['corrupt', 'evil', 'disgusting', 'horrible', 'terrible', 'awful', 'nasty'],
        'hope': ['hope', 'peace', 'freedom', 'victory', 'support', 'help', 'together', 'unity'],
        'surprise': ['shocking', 'unbelievable', 'incredible', 'unexpected', 'suddenly', 'wow'],
    }
    profile = {}
    for emotion, keywords in emotions.items():
        count = sum(1 for kw in keywords if kw in text_lower)
        profile[emotion] = count
    dominant = max(profile, key=profile.get)
    return {
        'emotions': profile,
        'dominant_emotion': dominant if profile[dominant] > 0 else 'neutral'
    }

def analyze_all(df: pd.DataFrame) -> pd.DataFrame:
    results = df['text'].apply(analyze_sentiment_score)
    results_df = pd.DataFrame(results.tolist())
    results_df.columns = [
        f'nlp_{c}' for c in results_df.columns
    ]

    emotions = df['text'].apply(get_emotion_profile)
    emotions_df = pd.DataFrame([
        e['emotions'] | {'dominant_emotion': e['dominant_emotion']}
        for e in emotions
    ])

    df = pd.concat([
        df.reset_index(drop=True),
        results_df.reset_index(drop=True),
        emotions_df.reset_index(drop=True)
    ], axis=1)
    return df

def get_sentiment_summary(df: pd.DataFrame) -> dict:
    if 'nlp_label' not in df.columns:
        df = analyze_all(df)

    total = len(df)
    counts = df['nlp_label'].value_counts().to_dict()

    return {
        'total': total,
        'positive': counts.get('positive', 0),
        'negative': counts.get('negative', 0),
        'neutral': counts.get('neutral', 0),
        'avg_score': round(df['nlp_score'].mean(), 3),
        'most_negative': df.loc[
            df['nlp_score'].idxmin(), 'text'
        ][:80] if len(df) > 0 else '',
        'most_positive': df.loc[
            df['nlp_score'].idxmax(), 'text'
        ][:80] if len(df) > 0 else '',
    }