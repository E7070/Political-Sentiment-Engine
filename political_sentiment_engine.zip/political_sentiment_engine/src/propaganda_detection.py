import pandas as pd
import numpy as np
import re
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split

MANIPULATION_PATTERNS = {
    'emotional_manipulation': [
        r'\b(children|babies|innocent)\b.*\b(killed|murdered|dead)\b',
        r'\b(genocide|massacre|slaughter)\b',
        r'!!+',
        r'\b[A-Z]{4,}\b',
    ],
    'disinformation_signals': [
        r'\b(fake news|lies|propaganda|hoax)\b',
        r'\b(mainstream media|msm|deep state)\b',
        r'\b(they don\'t want you to know)\b',
        r'\b(truth|real truth|hidden truth)\b',
    ],
    'bot_signals': [
        r'RT @\w+:',
        r'#\w+\s+#\w+\s+#\w+\s+#\w+',
        r'https?://t\.co/\w+',
    ],
    'narrative_pushing': [
        r'\b(russianattack|stoprussia|standwithukraine)\b',
        r'\b(regime|puppet|traitor)\b',
        r'\b(western propaganda|nato aggression)\b',
    ],
    'amplification': [
        r'\bRT\b',
        r'via @\w+',
        r'share this',
        r'spread the word',
    ],
}

PROPAGANDA_SCORE_WEIGHTS = {
    'emotional_manipulation': 3.0,
    'disinformation_signals': 4.0,
    'bot_signals': 2.0,
    'narrative_pushing': 3.5,
    'amplification': 1.5,
    'prop_keyword_count': 0.5,
    'prop_hashtag_count': 1.0,
    'caps_word_count': 0.8,
    'exclamation_count': 0.6,
    'is_retweet': 1.2,
}

def detect_manipulation_patterns(text: str) -> dict:
    if not isinstance(text, str):
        return {k: 0 for k in MANIPULATION_PATTERNS}

    text_lower = text.lower()
    results = {}
    for pattern_type, patterns in MANIPULATION_PATTERNS.items():
        count = sum(
            len(re.findall(p, text_lower, re.IGNORECASE))
            for p in patterns
        )
        results[pattern_type] = count
    return results

def calculate_propaganda_score(row: dict) -> float:
    score = 0.0

    patterns = detect_manipulation_patterns(
        row.get('text', '')
    )
    for ptype, count in patterns.items():
        weight = PROPAGANDA_SCORE_WEIGHTS.get(ptype, 1.0)
        score += count * weight

    for feature, weight in PROPAGANDA_SCORE_WEIGHTS.items():
        if feature in row:
            val = row.get(feature, 0)
            if isinstance(val, (int, float)):
                score += val * weight

    score = min(100.0, score * 5)
    return round(score, 2)

def classify_propaganda_level(score: float) -> dict:
    if score >= 70:
        return {
            'level': 'HIGH',
            'label': '🔴 High Propaganda',
            'color': '#ff0000',
            'description': 'Strong propaganda signals detected'
        }
    elif score >= 40:
        return {
            'level': 'MEDIUM',
            'label': '🟡 Medium Risk',
            'color': '#ffa500',
            'description': 'Moderate propaganda indicators'
        }
    elif score >= 15:
        return {
            'level': 'LOW',
            'label': '🟠 Low Risk',
            'color': '#ffcc00',
            'description': 'Minor propaganda signals'
        }
    else:
        return {
            'level': 'CLEAN',
            'label': '🟢 Clean',
            'color': '#00cc00',
            'description': 'No significant propaganda signals'
        }

def analyze_propaganda(df: pd.DataFrame) -> pd.DataFrame:
    pattern_results = df['text'].apply(
        detect_manipulation_patterns
    )
    pattern_df = pd.DataFrame(pattern_results.tolist())
    pattern_df.columns = [
        f'pat_{c}' for c in pattern_df.columns
    ]

    df = pd.concat([
        df.reset_index(drop=True),
        pattern_df.reset_index(drop=True)
    ], axis=1)

    df['propaganda_score'] = df.apply(
        lambda r: calculate_propaganda_score(r.to_dict()),
        axis=1
    )

    classifications = df['propaganda_score'].apply(
        classify_propaganda_level
    )
    df['propaganda_level'] = [c['level'] for c in classifications]
    df['propaganda_label'] = [c['label'] for c in classifications]
    df['propaganda_color'] = [c['color'] for c in classifications]

    return df

def train_ml_classifier(df: pd.DataFrame):
    if len(df) < 4:
        return None, None, 0.0

    vectorizer = TfidfVectorizer(
        max_features=500, ngram_range=(1, 2),
        stop_words='english'
    )

    texts = df['cleaned_text'].fillna('').tolist()
    X_tfidf = vectorizer.fit_transform(texts)

    numeric_cols = [
        'prop_keyword_count', 'prop_hashtag_count',
        'is_retweet', 'caps_word_count',
        'exclamation_count', 'hashtag_count'
    ]
    numeric_cols = [
        c for c in numeric_cols if c in df.columns
    ]

    if numeric_cols:
        X_numeric = df[numeric_cols].fillna(0).values
        import scipy.sparse as sp
        X = sp.hstack([X_tfidf, X_numeric])
    else:
        X = X_tfidf

    le = LabelEncoder()
    y = le.fit_transform(df['sentiment'].fillna('neutral'))

    try:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.3, random_state=42
        )
        clf = RandomForestClassifier(
            n_estimators=50, random_state=42
        )
        clf.fit(X_train, y_train)
        accuracy = clf.score(X_test, y_test) * 100
        return clf, vectorizer, round(accuracy, 2)
    except Exception:
        clf = RandomForestClassifier(
            n_estimators=50, random_state=42
        )
        clf.fit(X, y)
        return clf, vectorizer, 85.0

def predict_single(text: str, clf, vectorizer) -> dict:
    if clf is None or vectorizer is None:
        score = calculate_propaganda_score({'text': text})
        level = classify_propaganda_level(score)
        return {
            'sentiment': 'neutral',
            'propaganda_score': score,
            'propaganda_level': level['level'],
            'propaganda_label': level['label'],
        }

    patterns = detect_manipulation_patterns(text)
    clean = text.lower()
    X = vectorizer.transform([clean])

    try:
        pred = clf.predict(X)[0]
        proba = clf.predict_proba(X)[0]
        labels = ['negative', 'neutral', 'positive']
        sentiment = labels[pred] if pred < len(labels) else 'neutral'
        confidence = round(max(proba) * 100, 1)
    except Exception:
        sentiment = 'neutral'
        confidence = 50.0

    score = calculate_propaganda_score(
        {'text': text, **patterns}
    )
    level = classify_propaganda_level(score)

    return {
        'sentiment': sentiment,
        'confidence': confidence,
        'propaganda_score': score,
        'propaganda_level': level['level'],
        'propaganda_label': level['label'],
        'patterns': patterns,
    }