import pandas as pd
import numpy as np
import networkx as nx
from collections import defaultdict

def build_user_network(df: pd.DataFrame) -> nx.DiGraph:
    G = nx.DiGraph()

    for _, row in df.iterrows():
        user = row.get('user', 'unknown')
        sentiment = row.get('sentiment', 'neutral')
        prop_score = row.get('propaganda_score', 0)

        if not G.has_node(user):
            G.add_node(user,
                tweet_count=0,
                sentiment=sentiment,
                propaganda_score=prop_score,
                is_bot_suspect=False
            )
        G.nodes[user]['tweet_count'] = \
            G.nodes[user].get('tweet_count', 0) + 1
        G.nodes[user]['propaganda_score'] = max(
            G.nodes[user].get('propaganda_score', 0),
            prop_score
        )

    import re
    for _, row in df.iterrows():
        text = str(row.get('text', ''))
        user = row.get('user', 'unknown')
        rt_match = re.search(r'RT @(\w+)', text)
        if rt_match:
            source = rt_match.group(1)
            if not G.has_node(source):
                G.add_node(source,
                    tweet_count=0,
                    sentiment='neutral',
                    propaganda_score=0,
                    is_bot_suspect=False
                )
            if G.has_edge(source, user):
                G[source][user]['weight'] += 1
            else:
                G.add_edge(source, user, weight=1)

    user_hashtags = defaultdict(set)
    for _, row in df.iterrows():
        user = row.get('user', 'unknown')
        tags = row.get('hashtags', [])
        if isinstance(tags, list):
            user_hashtags[user].update(tags)

    users = list(user_hashtags.keys())
    for i in range(len(users)):
        for j in range(i + 1, len(users)):
            u1, u2 = users[i], users[j]
            shared = user_hashtags[u1] & user_hashtags[u2]
            if shared and u1 in G and u2 in G:
                if not G.has_edge(u1, u2):
                    G.add_edge(u1, u2, weight=len(shared),
                               edge_type='hashtag_share')

    return G

def detect_bot_suspects(G: nx.DiGraph, df: pd.DataFrame) -> dict:
    bot_suspects = {}

    for node in G.nodes():
        score = 0
        flags = []

        node_df = df[df['user'] == node]
        if len(node_df) > 0:
            rt_ratio = node_df['is_retweet'].mean()
            if rt_ratio > 0.7:
                score += 30
                flags.append('High RT ratio')

        prop_score = G.nodes[node].get('propaganda_score', 0)
        if prop_score > 60:
            score += 25
            flags.append('High propaganda score')

        degree = G.degree(node)
        if degree > 3:
            score += 20
            flags.append('High network degree')

        if len(node_df) > 0:
            avg_tags = node_df['hashtag_count'].mean()
            if avg_tags > 5:
                score += 15
                flags.append('Excessive hashtags')

        bot_suspects[node] = {
            'bot_score': min(100, score),
            'flags': flags,
            'is_suspect': score >= 40
        }

        G.nodes[node]['is_bot_suspect'] = score >= 40
        G.nodes[node]['bot_score'] = min(100, score)

    return bot_suspects

def get_network_stats(G: nx.DiGraph) -> dict:
    if len(G.nodes()) == 0:
        return {}

    try:
        centrality = nx.degree_centrality(G)
        betweenness = nx.betweenness_centrality(G)
        most_central = max(centrality, key=centrality.get)
        most_influential = max(betweenness, key=betweenness.get)
    except Exception:
        centrality = {}
        betweenness = {}
        most_central = 'N/A'
        most_influential = 'N/A'

    return {
        'total_nodes': G.number_of_nodes(),
        'total_edges': G.number_of_edges(),
        'most_central_user': most_central,
        'most_influential_user': most_influential,
        'avg_degree': round(
            sum(dict(G.degree()).values()) / max(G.number_of_nodes(), 1),
            2
        ),
        'centrality': centrality,
        'betweenness': betweenness,
    }

def get_propaganda_clusters(
    G: nx.DiGraph, df: pd.DataFrame
) -> list:
    undirected = G.to_undirected()
    clusters = []
    try:
        components = list(
            nx.connected_components(undirected)
        )
        for i, component in enumerate(components):
            sub_df = df[df['user'].isin(component)]
            avg_prop = sub_df['propaganda_score'].mean() \
                if 'propaganda_score' in sub_df.columns \
                and len(sub_df) > 0 else 0
            clusters.append({
                'cluster_id': i + 1,
                'users': list(component),
                'size': len(component),
                'avg_propaganda_score': round(avg_prop, 2),
                'risk_level': 'HIGH' if avg_prop > 50
                              else 'MEDIUM' if avg_prop > 25
                              else 'LOW'
            })
    except Exception:
        pass
    return sorted(
        clusters, key=lambda x: x['avg_propaganda_score'],
        reverse=True
    )